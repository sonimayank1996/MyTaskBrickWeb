import React, { useState } from "react";
import Card from "react-bootstrap/Card";
import Button from "react-bootstrap/Button";
import { cardAction } from "./redux/actions/cardItemAction";
import { useDispatch, useSelector } from "react-redux";

let a= [];
const Dashboard = () => {
  const dispatch = useDispatch();
  const [counter, setCounter] = useState(0);
  let item = [
    {
      id: 1,
      image:
        "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8cHJvZHVjdHxlbnwwfHwwfHw%3D&w=1000&q=80",
      name: "headphone",
    },
    {
      id: 2,
      image:
        "https://images.pexels.com/photos/90946/pexels-photo-90946.jpeg?cs=srgb&dl=pexels-math-90946.jpg&fm=jpg",
      name: "camera",
    },
    {
      id: 3,
      image:
        "https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8cHJvZHVjdHxlbnwwfHwwfHw%3D&w=1000&q=80",
      name: "watch",
    },
  ];
 
  const handleAddToCart = (ele) => {
    setCounter((pre) => pre + 1);
    a = [...a, ele];
    console.log('object', a)
     dispatch(cardAction(counter + 1, a));
  };
  return (
    <div style={{ display: "flex" }}>
      {item.map((ele) => {
        return (
          <Card style={{ width: "18rem", margin: "20px" }}>
            <Card.Img variant="top" src={ele.image} />
            <Card.Body>
              <Card.Title>{ele.name}</Card.Title>
            </Card.Body>
            <Button onClick={() => handleAddToCart(ele)}>Add To Cart</Button>
          </Card>
        );
      })}
    </div>
  );
};

export default Dashboard;
