import React from "react";
import Card from "react-bootstrap/Card";
import { useDispatch, useSelector } from "react-redux";

const CartPages = () => {
    const statesArray = useSelector(state => state);
    console.log('statesarray', statesArray.cartItem.count)
  return (
    <div style={{ display: "flex" }}>
      {statesArray.cartItem.count ? statesArray.cartItem.count.map((ele) => {
        return (
          <Card style={{ width: "18rem", margin: "20px" }}>
            <Card.Img variant="top" src={ele.image} />
            <Card.Body>
              <Card.Title>{ele.name}</Card.Title>
            </Card.Body>
          </Card>
        );
      }) : 'No Item Found'}
    </div>
  );
};

export default CartPages;
