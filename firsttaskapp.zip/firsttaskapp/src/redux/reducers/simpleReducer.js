export default (state = {}, action) => {
  console.log('object11', action);
    switch (action.type) {
     case 'SIMPLE_ACTION':
      return {
       token: action.payload
      }
     default:
      return state
    }
   }