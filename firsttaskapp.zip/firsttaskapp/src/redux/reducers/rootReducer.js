import { combineReducers } from 'redux';
import cardItemReducer from './cardItemReducer';
import simpleReducer from './simpleReducer';
export default combineReducers({
 simple: simpleReducer,
 cartItem: cardItemReducer
});