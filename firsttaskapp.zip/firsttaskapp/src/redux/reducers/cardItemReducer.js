export default (state = { count: 0 }, action) => {
  switch (action.type) {
    case "Cart_Item":
      return {
        count: action.payload,
      };
    default:
      return state;
  }
};
