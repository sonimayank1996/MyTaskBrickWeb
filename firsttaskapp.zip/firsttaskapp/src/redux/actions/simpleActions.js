export const simpleAction = (token, obj)  => {
    return {
     type: 'SIMPLE_ACTION',
     payload: token
    }
   }