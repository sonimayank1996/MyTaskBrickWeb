import React from "react";
import Container from "react-bootstrap/Container";
import Navbar from "react-bootstrap/Navbar";
import Nav from "react-bootstrap/Nav";
import { AiOutlineShoppingCart } from "react-icons/ai";
import { useDispatch, useSelector } from "react-redux";
import { Link, useNavigate } from 'react-router-dom';
import { Button } from "@mui/material";
const Header = () => {
let nav = useNavigate()
  const logout = () => {
    localStorage.removeItem('token');
    nav('/')
  }
    const state = useSelector(state => state)
    let token = localStorage.getItem('token')
    // console.log('state', state.simple.token[1])
  return (
    <Navbar bg="dark" variant="dark">
      <Container>
        <Navbar.Brand href="#home">Shopping</Navbar.Brand>
        <Nav className="me-auto">
          <Link style={{marginRight: '10px'}} to="/dashboard">Home</Link>
          <Link style={{marginRight: '10px'}} to="/cart" style={{ alignContent: "right" }}>
            <AiOutlineShoppingCart />
            <span class="badge badge-warning" id="lblCartCount">
              {" "}
              {state.cartItem.count.length}{" "}
            </span>
          </Link>
          {token && <Button style={{marginRight: '10px'}} onClick={logout}>Logout</Button>}
        </Nav>
      </Container>
    </Navbar>
  );
};

{
  /* <i class="bi bi-cart-fill"></i> */
}
export default Header;
