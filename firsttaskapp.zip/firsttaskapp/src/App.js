import React, { useEffect, useState } from "react";
import "./App.css";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import { simpleAction } from "./redux/actions/simpleActions";
import { useDispatch, useSelector } from "react-redux";
import Login from "./login";
import Dashboard from "./dashboard";
import { Routes, Route, Router, useNavigate } from "react-router-dom";
import Header from "./header";
import CartPages from "./cartPage";

function App() {
  let navigation = useNavigate()
  let obj = {};
  useEffect(() => {
    let token = localStorage.getItem('token');
    if(token) {
      navigation('/dashboard')
    }
  }, [])
  return (
    <div className="App">
      <div className="App">
        <Header />{" "}
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/cart" element={<CartPages />} />
        </Routes>
      </div>
    </div>
  );
}

export default App;
